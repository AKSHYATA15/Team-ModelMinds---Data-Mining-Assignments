
path_apriori_executable=$1
path_fp_executable=$2
path_dataset=$3
path_out=$4

python3 run_and_plot.py "$path_apriori_executable" "$path_fp_executable" "$path_dataset" "$path_out"
