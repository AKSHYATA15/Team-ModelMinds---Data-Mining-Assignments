universal_itemset=$1
num_transactions=$2

python3 generate_dataset.py "$universal_itemset" "$num_transactions"
