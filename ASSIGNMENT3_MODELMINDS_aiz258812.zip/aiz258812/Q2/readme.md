
**Kerberos:** aiz258812

## Environment

- Python: 3.10+ 
- PyTorch: 2.7+ (tested on PyTorch 2.7 with CUDA 12.x on Kaggle T4 GPUs)
- PyTorch Geometric: 2.7.0 
- Other dependencies: see requirements.txt

The code uses only standard PyTorch and PyG operations available across
multiple versions, so it should also be compatible with PyTorch 2.5,
2.2, and 1.13 if needed.

## Architectures

(All GNN-based architectures):

- **A** (node classification, 7 classes): 10-seed ensemble of 2-layer
  APPNP (K=10, alpha=0.1) — `model_A_appnp_xl.py`
- **B** (binary node classification on a 2.9M-node graph):
  3-seed ensemble of 2-layer GraphSAGE with shared-subgraph inference
  for memory efficiency — `model_B_v6.py`
- **C** (link prediction with 500 hard negatives):
  5-seed ensemble of 8-layer GCNII encoder + MLP decoder
  — `model_C_gcnii.py`

## Training times (Kaggle T4 GPU)

- A: ~3 minutes
- B: ~55 minutes  
- C: ~3 minutes

## Files

The `Q2/src/` directory contains:
- `load_dataset.py`, `evaluate.py`: assignment originals, unchanged
- `predict.py`: only the `predict_B` editable block was modified
  (between the `################` markers) to call `model.inference()`
  for batched inference on the 2.9M-node graph
- `train.py`: trainer that dispatches to the correct per-dataset module
- `model_A_appnp.py`, `model_A_appnp_xl.py`: A's GNN models
- `model_B.py`, `model_B_v2.py`, `model_B_v6.py`: B's GNN models
- `model_C_gcnii.py`: C's GNN model