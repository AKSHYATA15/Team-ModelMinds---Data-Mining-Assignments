#!/bin/bash

# Upgrade pip
python3 -m pip install --upgrade pip

# Install required libraries
python3 -m pip install numpy matplotlib scikit-learn