import sys
import urllib.request
import json
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans

MAX_K = 15
KERBEROS_ID = "aiz258812"

def load_dataset_from_api(dataset_num):

    url = f"http://hulk.cse.iitd.ac.in:3000/dataset?student_id={KERBEROS_ID}&dataset_num={dataset_num}"

    #### LLM-assisted code (ChatGPT); all logic and correctness verified by the authors.
    with urllib.request.urlopen(url) as response:
        raw_data = response.read().decode("utf-8")
        data = json.loads(raw_data)
    ####

    X = np.array(data["X"])

    return X


def load_dataset_from_npy(path):

    return np.load(path)


def compute_objectives(X):

    objectives = []

    for k in range(1, MAX_K + 1):

        kmeans = KMeans(n_clusters=k, n_init=10, random_state=42)

        kmeans.fit(X)

        objectives.append(kmeans.inertia_)

    return objectives


def find_elbow(objectives):

    ks = np.arange(1, len(objectives) + 1)

    p1 = np.array([ks[0], objectives[0]])
    p2 = np.array([ks[-1], objectives[-1]])

    distances = []

    for k, obj in zip(ks, objectives):

        p = np.array([k, obj])

        num = np.abs(np.cross(p2 - p1, p1 - p))
        den = np.linalg.norm(p2 - p1)

        distances.append(num / den)

    optimal_k = ks[np.argmax(distances)]

    return optimal_k


def main():

    if len(sys.argv) != 2:
        print("Usage:")
        print("python3 Q1.py <dataset_num>")
        print("python3 Q1.py <dataset.npy>")
        sys.exit(1)

    arg = sys.argv[1]
    ks = np.arange(1, MAX_K + 1)

    if arg.isdigit():

        X1 = load_dataset_from_api(1)
        X2 = load_dataset_from_api(2)

        obj1 = compute_objectives(X1)
        obj2 = compute_objectives(X2)

        k1 = find_elbow(obj1)
        k2 = find_elbow(obj2)

        fig, axes = plt.subplots(1, 2, figsize=(12,4))
        #### LLM-assisted code (ChatGPT); all logic and correctness verified by the authors.
        axes[0].plot(ks, obj1, marker='o')
        axes[0].set_xlabel("k")
        axes[0].set_ylabel("K-means Objective")
        axes[0].set_xticks(ks)
        axes[0].set_title(f"{KERBEROS_ID}_dataset_1")

        axes[1].plot(ks, obj2, marker='o')
        axes[1].set_xlabel("k")
        axes[1].set_ylabel("K-means Objective")
        axes[1].set_xticks(ks)
        axes[1].set_title(f"{KERBEROS_ID}_dataset_2")

        plt.tight_layout()
        plt.savefig("plot.png")
        ####

        print(f"{k1},{k2}")

    else:

        X = load_dataset_from_npy(arg)

        objectives = compute_objectives(X)

        k = find_elbow(objectives)

        fig, ax = plt.subplots(figsize=(6,4))
        #### LLM-assisted code (ChatGPT); all logic and correctness verified by the authors.
        ax.plot(ks, objectives, marker='o')
        ax.set_xlabel("k")
        ax.set_ylabel("K-means Objective")
        ax.set_xticks(ks)
        ax.set_title(f"{KERBEROS_ID}_npy_dataset")

        plt.tight_layout()
        plt.savefig("plot.png")
        ####

        print(k)


if __name__ == "__main__":
    main()