#!/bin/bash

python3 - "$@" << 'PYCODE'
import sys,random,time
from collections import defaultdict,deque

if len(sys.argv)!=7:
    sys.exit(1)

graph_path=sys.argv[1]
seed_path=sys.argv[2]
out_path=sys.argv[3]
k=int(sys.argv[4])
r=int(sys.argv[5])
hops=int(sys.argv[6])

TIME_LIMIT=3300
start=time.time()

open(out_path,"w").close()

graph=defaultdict(list)
prob={}
edges=[]
nodes=set()

with open(graph_path) as f:
    for line in f:
        u,v,p=line.split()
        u=int(u);v=int(v);p=float(p)
        graph[u].append((v,p))
        prob[(u,v)]=p
        edges.append((u,v))
        nodes.add(u);nodes.add(v)

nodes=list(nodes)

seeds=set()
with open(seed_path) as f:
    for line in f:
        if line.strip():
            seeds.add(int(line))

# subtree size
subtree=defaultdict(int)
for v in nodes:
    vis={v}
    q=deque([v])
    c=0
    while q:
        u=q.popleft()
        c+=1
        for w,_ in graph[u]:
            if w not in vis:
                vis.add(w)
                q.append(w)
    subtree[v]=c


def simulate(blocked):

    blocked=set(blocked)
    vis=set(seeds)
    q=deque([(s,0) for s in seeds])
    used=[]

    while q:

        u,d=q.popleft()

        if hops!=-1 and d>=hops:
            continue

        for v,p in graph[u]:

            if (u,v) in blocked: continue
            if v in vis: continue

            if random.random()<=p:
                vis.add(v)
                q.append((v,d+1))
                used.append((u,v,d))

    return vis,used


def greedy():

    CASCADE_SIMS=max(12000,r*400 if r>0 else 12000)

    blocked=set()

    for step in range(k):

        cascade=defaultdict(float)
        freq=defaultdict(float)

        for _ in range(CASCADE_SIMS):

            if time.time()-start>TIME_LIMIT:
                break

            vis,used=simulate(blocked)
            size=len(vis)

            #### LLM-assisted code (ChatGPT); all logic and correctness verified by the authors.
            for u,v,d in used:

                if (u,v) in blocked: continue

                w=1/((d+1)**2)
                if d<=2: w*=2.8

                cascade[(u,v)]+=w*size
                freq[(u,v)]+=w*subtree[v]
            ####

        scores={}

        for e in cascade:
            scores[e]=(
                0.65*cascade[e]
                +0.25*freq[e]
                +0.10*prob[e]
            )

        if not scores: break

        best=max(scores.items(),key=lambda x:x[1])[0]
        blocked.add(best)

        with open(out_path,"a") as f:
            f.write(f"{best[0]} {best[1]}\n")

    return blocked


def estimate(blocked):

    sims=2000
    tot=0

    for _ in range(sims):
        vis,_=simulate(blocked)
        tot+=len(vis)

    return tot/sims


best=None
best_score=1e18

# multiple runs
for seed in range(1,6):

    #### LLM-assisted code (ChatGPT); all logic and correctness verified by the authors.
    random.seed(seed)

    cand=greedy()

    score=estimate(cand)

    if score<best_score:
        best_score=score
        best=cand
    ####


# ensure exactly k edges
for e in edges:
    if len(best)>=k: break
    if e not in best: best.add(e)

# Final write of exactly k edges
with open(out_path,"w") as f:
    for u,v in list(best)[:k]:
        f.write(f"{u} {v}\n")

PYCODE
