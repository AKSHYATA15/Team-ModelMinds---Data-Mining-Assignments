import numpy as np
import faiss


def solve(base_vectors, query_vectors, k, K, time_budget):
    base = np.ascontiguousarray(base_vectors, dtype=np.float32)
    query = np.ascontiguousarray(query_vectors, dtype=np.float32)

    N, d = int(base.shape[0]), int(base.shape[1])
    Q = int(query.shape[0])
    k_eff = max(1, min(int(k), N))
    K_eff = max(0, min(int(K), N))

    if N <= 700_000:
        index = faiss.IndexFlatL2(d)
        index.add(base)
    else:
        nlist = 4096
        nprobe = 384
        quantizer = faiss.IndexFlatL2(d)
        index = faiss.IndexIVFFlat(quantizer, d, nlist, faiss.METRIC_L2)
        index.cp.niter = 8
        index.cp.max_points_per_centroid = 16
        index.train(base)
        index.add(base)
        index.nprobe = nprobe

    batch_size = 4096
    I_all = np.empty((Q, k_eff), dtype=np.int64)
    for start in range(0, Q, batch_size):
        end = start + batch_size
        if end > Q:
            end = Q
        _, I_batch = index.search(query[start:end], k_eff)
        I_all[start:end] = I_batch

    flat = I_all.ravel()
    flat = flat[flat >= 0]
    counts = np.bincount(flat, minlength=N)
    order = np.argsort(-counts, kind='stable')
    return order[:K_eff].astype(np.int64, copy=False)
