
import os
import time

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import APPNP

from load_dataset import load_dataset


class CoraAPPNP(nn.Module):
    def __init__(self, in_dim, hidden_dim, out_dim,
                 K=10, alpha=0.1, dropout=0.5):
        super().__init__()
        self.lin1 = nn.Linear(in_dim, hidden_dim)
        self.lin2 = nn.Linear(hidden_dim, out_dim)
        self.prop = APPNP(K=K, alpha=alpha)
        self.dropout = dropout

    def forward(self, x, edge_index):
        x = F.dropout(x, p=self.dropout, training=self.training)
        x = self.lin1(x)
        x = F.relu(x)
        x = F.dropout(x, p=self.dropout, training=self.training)
        x = self.lin2(x)
        x = self.prop(x, edge_index)
        return x


class EnsembleA(nn.Module):
    def __init__(self, members):
        super().__init__()
        self.members = nn.ModuleList(members)

    def forward(self, x, edge_index):
        out = None
        for m in self.members:
            logits = m(x, edge_index)
            out = logits if out is None else out + logits
        return out / len(self.members)


def _train_one_seed(seed, data, n_feat, n_cls, device, time_budget_s):
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    model = CoraAPPNP(n_feat, 64, n_cls, K=10, alpha=0.1, dropout=0.5).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.01, weight_decay=5e-3)

    train_idx = data.labeled_nodes[data.train_mask]
    val_idx = data.labeled_nodes[data.val_mask]
    train_y = data.y[data.train_mask]
    val_y = data.y[data.val_mask]

    best_val_acc = 0.0
    best_state = None
    max_epochs = 3000
    patience = 800
    counter = 0
    start = time.time()

    for epoch in range(max_epochs):
        if time.time() - start > time_budget_s:
            break

        model.train()
        optimizer.zero_grad()
        logits = model(data.x, data.edge_index)
        loss = F.cross_entropy(logits[train_idx], train_y)
        loss.backward()
        optimizer.step()

        model.eval()
        with torch.no_grad():
            logits = model(data.x, data.edge_index)
            val_acc = (logits[val_idx].argmax(dim=1) == val_y).float().mean().item()

        if val_acc > best_val_acc:
            best_val_acc = val_acc
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            counter = 0
        else:
            counter += 1
            if counter >= patience:
                break

        if epoch % 200 == 0:
            print(f"[A-appnp][seed={seed}] Epoch {epoch:4d} | Loss {loss.item():.4f} | "
                  f"Val Acc {val_acc:.4f} | Best {best_val_acc:.4f}")

    member = CoraAPPNP(n_feat, 64, n_cls, K=10, alpha=0.1, dropout=0.5)
    if best_state is not None:
        member.load_state_dict(best_state)
    member.eval()
    print(f"[A-appnp][seed={seed}] Best val acc = {best_val_acc:.4f}")
    return member, best_val_acc


def train_A_appnp(args) -> None:
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"[A-appnp] Device: {device}")

    ds = load_dataset("A", args.data_dir)
    data = ds[0].to(device)
    n_feat = int(data.x.shape[1])
    n_cls = ds.num_classes
    print(f"[A-appnp] Nodes={data.num_nodes}, Features={n_feat}, Classes={n_cls}")

    seeds = [42, 7, 123, 2024, 0]
    total_budget = 0.85 * 3600.0
    per_seed = total_budget / len(seeds)

    members = []
    for s in seeds:
        m, _ = _train_one_seed(s, data, n_feat, n_cls, device, per_seed)
        members.append(m)

    ensemble = EnsembleA(members).to(device).eval()
    val_idx = data.labeled_nodes[data.val_mask]
    val_y = data.y[data.val_mask]
    with torch.no_grad():
        ens_logits = ensemble(data.x, data.edge_index)
        ens_val_acc = (ens_logits[val_idx].argmax(dim=1) == val_y).float().mean().item()
    print(f"[A-appnp] Ensemble validation accuracy: {ens_val_acc:.4f}")

    os.makedirs(args.model_dir, exist_ok=True)
    save_path = os.path.join(args.model_dir, f"{args.kerberos}_model_A.pt")
    ensemble = ensemble.cpu().eval()
    torch.save(ensemble, save_path)
    print(f"[A-appnp] Saved APPNP ensemble ({len(members)} members) to {save_path}")
