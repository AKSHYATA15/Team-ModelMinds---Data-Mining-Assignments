
import os
import time

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import SAGEConv

from load_dataset import load_dataset



class BinaryNodeSAGE(nn.Module):
    """
    Single-layer GraphSAGE sandwiched between two MLPs.

    The .inference method is called by predict.py to score every node
    in batches (same sampling strategy as training).
    """

    def __init__(
        self,
        in_dim: int,
        hidden_dim: int = 128,
        out_dim: int = 2,
        num_layers: int = 1,
        dropout: float = 0.2,
    ):
        super().__init__()
        self.in_dim = in_dim
        self.hidden_dim = hidden_dim
        self.out_dim = out_dim
        self.num_layers = num_layers          
        self.dropout = dropout

        self.input_proj = nn.Linear(in_dim, hidden_dim)
        self.input_ln = nn.LayerNorm(hidden_dim)
        self.conv = SAGEConv(hidden_dim, hidden_dim)
        self.conv_ln = nn.LayerNorm(hidden_dim)
        self.classifier = nn.Linear(hidden_dim, out_dim)

    def forward(self, x, edge_index):
        x = self.input_proj(x)
        x = self.input_ln(x)
        x = F.relu(x)
        x = F.dropout(x, p=self.dropout, training=self.training)

        x = self.conv(x, edge_index)
        x = self.conv_ln(x)
        x = F.relu(x)
        x = F.dropout(x, p=self.dropout, training=self.training)

        return self.classifier(x)


    @torch.no_grad()
    def inference(self, x_all, edge_index, batch_size: int = 1024,
                   max_neighbors: int = 25):
 
        self.eval()
        device = next(self.parameters()).device
        N = x_all.shape[0]


        nbrs = _build_neighbor_list(edge_index, N)

        out = torch.empty((N, self.out_dim), dtype=torch.float32)

        for start in range(0, N, batch_size):
            end = min(start + batch_size, N)
            target_nodes = torch.arange(start, end)

            subset, sub_ei, mapping = _sample_subgraph(
                target_nodes, nbrs, max_neighbors=max_neighbors,
            )

            sub_x = x_all[subset].to(device, non_blocking=True)
            sub_ei_dev = sub_ei.to(device, non_blocking=True)
            logits = self(sub_x, sub_ei_dev)
            out[start:end] = logits[mapping].cpu()

            del subset, sub_ei, sub_ei_dev, mapping, sub_x, logits
            if device.type == "cuda":
                torch.cuda.empty_cache()

        return out


def _build_neighbor_list(edge_index, N):

    row, col = edge_index[0].contiguous(), edge_index[1].contiguous()

    order = torch.argsort(row, stable=True)
    row_sorted = row[order]
    col_sorted = col[order]


    counts = torch.bincount(row_sorted, minlength=N)
    offsets = torch.empty(N + 1, dtype=torch.long)
    offsets[0] = 0
    torch.cumsum(counts, dim=0, out=offsets[1:])
    return offsets, col_sorted


def _sample_subgraph(target_nodes, nbrs, max_neighbors: int):

    offsets, col_sorted = nbrs
    sampled_src = []
    sampled_dst = []

    for v in target_nodes.tolist():
        s, e = int(offsets[v].item()), int(offsets[v + 1].item())
        deg = e - s
        if deg == 0:
            continue
        if deg <= max_neighbors:
            chosen = col_sorted[s:e]
        else:
            pick = torch.randint(0, deg, (max_neighbors,))
            chosen = col_sorted[s + pick]
        sampled_src.extend([v] * chosen.numel())
        sampled_dst.append(chosen)

    if sampled_dst:
        dst_all = torch.cat(sampled_dst)
    else:
        dst_all = torch.empty(0, dtype=torch.long)
    src_all = torch.tensor(sampled_src, dtype=torch.long)


    all_nodes = torch.cat([target_nodes, dst_all], dim=0)
    subset, inverse = torch.unique(all_nodes, return_inverse=True)


    mapping = inverse[: target_nodes.numel()]


    if src_all.numel() > 0:
        src_local = inverse[target_nodes.numel():].new_empty(src_all.numel())

        pos_of_target = {int(v): int(mapping[i]) for i, v in enumerate(target_nodes.tolist())}
        src_local = torch.tensor([pos_of_target[int(v)] for v in src_all.tolist()],
                                  dtype=torch.long)
        dst_local = inverse[target_nodes.numel():]
        sub_ei = torch.stack([src_local, dst_local], dim=0)
    else:
        sub_ei = torch.empty((2, 0), dtype=torch.long)

    return subset, sub_ei, mapping



def _compute_class_weights(train_y):
    pos = (train_y == 1).sum().item()
    neg = (train_y == 0).sum().item()
    total = max(pos + neg, 1)
    w0 = total / (2.0 * max(neg, 1))
    w1 = total / (2.0 * max(pos, 1))
    return torch.tensor([w0, w1], dtype=torch.float32), neg, pos


def train_B(args) -> None:
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    torch.manual_seed(42)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(42)
    np.random.seed(42)

    print(f"[B] Device: {device}")
    print("[B] Loading dataset ...")
    ds = load_dataset("B", args.data_dir)
    data = ds[0]
    N = int(data.x.shape[0])
    num_features = int(data.x.shape[1])
    print(f"[B] Nodes={N}, Edges={data.num_edges}, Features={num_features}")

    x_cpu = data.x
    edge_index_cpu = data.edge_index    

    full_y = torch.full((N,), -1, dtype=torch.long)
    full_y[data.labeled_nodes] = data.y.long()

    train_nodes_cpu = data.labeled_nodes[data.train_mask].clone()
    val_nodes_cpu = data.labeled_nodes[data.val_mask].clone()
    train_y_cpu = full_y[train_nodes_cpu]
    val_y_cpu = full_y[val_nodes_cpu]

    class_weight, neg, pos = _compute_class_weights(train_y_cpu)
    print(f"[B] Train: neg={neg}, pos={pos}, weights={class_weight.tolist()}")


    print("[B] Building neighbour list ...")
    t0 = time.time()
    nbrs = _build_neighbor_list(edge_index_cpu, N)
    print(f"[B] Neighbour list built in {time.time()-t0:.1f}s")

    model = BinaryNodeSAGE(
        in_dim=num_features,
        hidden_dim=128,
        out_dim=2,
        num_layers=1,
        dropout=0.2,
    ).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3, weight_decay=0.0)
    class_weight_dev = class_weight.to(device)

    from sklearn.metrics import roc_auc_score


    batch_size = 256
    val_batch_size = 1024
    max_neighbors = 25

    def run_batches(node_indices, batch_sz, shuffle, update):
        order = torch.randperm(node_indices.numel()) if shuffle else torch.arange(node_indices.numel())
        all_scores, all_labels = [], []
        total_loss, total_count = 0.0, 0

        for s in range(0, node_indices.numel(), batch_sz):
            idx = order[s:s + batch_sz]
            batch_targets = node_indices[idx]

            subset, sub_ei, mapping = _sample_subgraph(
                batch_targets, nbrs, max_neighbors=max_neighbors,
            )
            sub_x = x_cpu[subset].to(device, non_blocking=True)
            sub_ei_dev = sub_ei.to(device, non_blocking=True)

            logits = model(sub_x, sub_ei_dev)
            batch_logits = logits[mapping]
            y_batch = full_y[batch_targets].to(device)

            if update:
                optimizer.zero_grad()
                loss = F.cross_entropy(batch_logits, y_batch, weight=class_weight_dev)
                loss.backward()
                optimizer.step()
                total_loss += loss.item() * batch_targets.numel()
                total_count += batch_targets.numel()
            else:
                probs = torch.softmax(batch_logits, dim=1)[:, 1]
                all_scores.append(probs.detach().cpu().numpy())
                all_labels.append(y_batch.detach().cpu().numpy())

            del subset, sub_ei, sub_ei_dev, mapping, sub_x, logits, batch_logits, y_batch
            if device.type == "cuda":
                torch.cuda.empty_cache()

        if update:
            return total_loss / max(total_count, 1)
        return (
            np.concatenate(all_scores) if all_scores else np.array([]),
            np.concatenate(all_labels) if all_labels else np.array([]),
        )


    best_val_auc = 0.0
    best_state = None
    start = time.time()
    time_budget = 0.85 * 2 * 3600.0

    max_epochs = 30
    for epoch in range(max_epochs):
        if time.time() - start > time_budget:
            print(f"[B] Time budget reached at epoch {epoch}")
            break

        model.train()
        t0 = time.time()
        avg_loss = run_batches(train_nodes_cpu, batch_size, shuffle=True, update=True)
        t_train = time.time() - t0

        if time.time() - start > time_budget:
            print(f"[B] Budget nearly exhausted; stopping before val at epoch {epoch}")
            break

        model.eval()
        val_scores, val_labels = run_batches(
            val_nodes_cpu, val_batch_size, shuffle=False, update=False
        )
        try:
            val_auc = roc_auc_score(val_labels, val_scores)
        except ValueError:
            val_auc = 0.5

        elapsed = time.time() - start
        print(f"[B] Epoch {epoch:2d} | Loss {avg_loss:.4f} | Val AUC {val_auc:.4f} | "
              f"Train {t_train:.1f}s | Total {elapsed:.1f}s")

        if val_auc > best_val_auc:
            best_val_auc = val_auc
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}

    if best_state is not None:
        model.load_state_dict(best_state)

    os.makedirs(args.model_dir, exist_ok=True)
    save_path = os.path.join(args.model_dir, f"{args.kerberos}_model_B.pt")
    model = model.cpu().eval()
    torch.save(model, save_path)
    print(f"[B] Saved to {save_path}")
    print(f"[B] Best validation AUC: {best_val_auc:.4f}")
