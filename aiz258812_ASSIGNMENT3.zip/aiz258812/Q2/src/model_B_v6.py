
import os
import time

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from load_dataset import load_dataset

from model_B import (
    _build_neighbor_list,
    _compute_class_weights,
)
from model_B_v2 import (
    BinaryNodeSAGE2,
    _sample_subgraph_2hop,
)



class EnsembleB2(nn.Module):


    def __init__(self, members):
        super().__init__()
        self.members = nn.ModuleList(members)
        self.num_layers = members[0].num_layers if members else 2
        self.out_dim = members[0].out_dim if members else 2

    def forward(self, x, edge_index):
        out = None
        for m in self.members:
            logits = m(x, edge_index)
            out = logits if out is None else out + logits
        return out / len(self.members)

    @torch.no_grad()
    def inference(self, x_all, edge_index, batch_size: int = 512,
                   max_neighbors: int = 15):
        self.eval()
        device = next(self.members[0].parameters()).device
        N = x_all.shape[0]
        nbrs = _build_neighbor_list(edge_index, N)
        out = torch.empty((N, self.out_dim), dtype=torch.float32)

        for start in range(0, N, batch_size):
            end = min(start + batch_size, N)
            target_nodes = torch.arange(start, end)
            subset, sub_ei, mapping = _sample_subgraph_2hop(
                target_nodes, nbrs, max_neighbors=max_neighbors,
            )
            sub_x = x_all[subset].to(device, non_blocking=True)
            sub_ei_dev = sub_ei.to(device, non_blocking=True)

            agg = None
            for m in self.members:
                logits = m(sub_x, sub_ei_dev)
                agg = logits if agg is None else agg + logits
            agg = agg / len(self.members)
            out[start:end] = agg[mapping].cpu()

            del subset, sub_ei, sub_ei_dev, mapping, sub_x, agg
            if device.type == "cuda":
                torch.cuda.empty_cache()

        return out



def _train_one_seed(seed, x_cpu, full_y, train_nodes_cpu, val_nodes_cpu,
                     nbrs, N, num_features, class_weight, device,
                     time_budget_s):
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)

    model = BinaryNodeSAGE2(
        in_dim=num_features, hidden_dim=128, out_dim=2,
        num_layers=2, dropout=0.3,
    ).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3, weight_decay=0.0)
    class_weight_dev = class_weight.to(device)

    from sklearn.metrics import roc_auc_score

    batch_size = 96
    val_batch_size = 512
    max_neighbors = 15

    def run_batches(node_indices, batch_sz, shuffle, update):
        order = torch.randperm(node_indices.numel()) if shuffle else torch.arange(node_indices.numel())
        all_scores, all_labels = [], []
        total_loss, total_count = 0.0, 0

        for s in range(0, node_indices.numel(), batch_sz):
            idx = order[s:s + batch_sz]
            batch_targets = node_indices[idx]
            subset, sub_ei, mapping = _sample_subgraph_2hop(
                batch_targets, nbrs, max_neighbors=max_neighbors,
            )
            sub_x = x_cpu[subset].to(device, non_blocking=True)
            sub_ei_dev = sub_ei.to(device, non_blocking=True)
            logits = model(sub_x, sub_ei_dev)
            batch_logits = logits[mapping]
            y_batch = full_y[batch_targets].to(device)

            if update:
                optimizer.zero_grad()
                loss = F.cross_entropy(batch_logits, y_batch, weight=class_weight_dev)
                loss.backward()
                optimizer.step()
                total_loss += loss.item() * batch_targets.numel()
                total_count += batch_targets.numel()
            else:
                probs = torch.softmax(batch_logits, dim=1)[:, 1]
                all_scores.append(probs.detach().cpu().numpy())
                all_labels.append(y_batch.detach().cpu().numpy())

            del subset, sub_ei, sub_ei_dev, mapping, sub_x, logits, batch_logits, y_batch
            if device.type == "cuda":
                torch.cuda.empty_cache()

        if update:
            return total_loss / max(total_count, 1)
        return (
            np.concatenate(all_scores) if all_scores else np.array([]),
            np.concatenate(all_labels) if all_labels else np.array([]),
        )

    best_auc = 0.0
    best_state = None
    start = time.time()
    patience = 3
    no_improve = 0

    for epoch in range(20):
        if time.time() - start > time_budget_s:
            print(f"[B-v6][seed={seed}] time budget reached")
            break

        model.train()
        t0 = time.time()
        avg_loss = run_batches(train_nodes_cpu, batch_size, shuffle=True, update=True)
        t_train = time.time() - t0

        model.eval()
        val_scores, val_labels = run_batches(
            val_nodes_cpu, val_batch_size, shuffle=False, update=False
        )
        try:
            val_auc = roc_auc_score(val_labels, val_scores)
        except ValueError:
            val_auc = 0.5

        print(f"[B-v6][seed={seed}] Epoch {epoch:2d} | Loss {avg_loss:.4f} | "
              f"Val AUC {val_auc:.4f} | Train {t_train:.1f}s")

        if val_auc > best_auc:
            best_auc = val_auc
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            no_improve = 0
        else:
            no_improve += 1
            if no_improve >= patience:
                print(f"[B-v6][seed={seed}] Early stopping")
                break

    member = BinaryNodeSAGE2(
        in_dim=num_features, hidden_dim=128, out_dim=2,
        num_layers=2, dropout=0.3,
    )
    if best_state is not None:
        member.load_state_dict(best_state)
    member.eval()
    print(f"[B-v6][seed={seed}] Best AUC = {best_auc:.4f}")
    return member, best_auc


def train_B_v6(args) -> None:
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"[B-v6] Device: {device}")

    ds = load_dataset("B", args.data_dir)
    data = ds[0]
    N = int(data.x.shape[0])
    num_features = int(data.x.shape[1])
    print(f"[B-v6] Nodes={N}, Edges={data.num_edges}, Features={num_features}")

    x_cpu = data.x
    edge_index_cpu = data.edge_index

    full_y = torch.full((N,), -1, dtype=torch.long)
    full_y[data.labeled_nodes] = data.y.long()

    train_nodes_cpu = data.labeled_nodes[data.train_mask].clone()
    val_nodes_cpu = data.labeled_nodes[data.val_mask].clone()
    train_y_cpu = full_y[train_nodes_cpu]

    class_weight, neg, pos = _compute_class_weights(train_y_cpu)
    print(f"[B-v6] Train: neg={neg}, pos={pos}, weights={class_weight.tolist()}")

    print("[B-v6] Building neighbour list ...")
    t0 = time.time()
    nbrs = _build_neighbor_list(edge_index_cpu, N)
    print(f"[B-v6] Neighbour list built in {time.time()-t0:.1f}s")

    seeds = [42, 7, 123]
    total_budget = 0.85 * 2 * 3600.0
    per_seed = total_budget / len(seeds)

    members = []
    for s in seeds:
        member, _ = _train_one_seed(
            s, x_cpu, full_y, train_nodes_cpu, val_nodes_cpu,
            nbrs, N, num_features, class_weight, device, per_seed,
        )
        members.append(member)

    ensemble = EnsembleB2([m.to(device) for m in members]).eval()

    from sklearn.metrics import roc_auc_score
    print("[B-v6] Evaluating ensemble on val ...")
    val_batch_size = 512
    max_neighbors = 15

    all_scores, all_labels = [], []
    for s in range(0, val_nodes_cpu.numel(), val_batch_size):
        batch_targets = val_nodes_cpu[s:s + val_batch_size]
        subset, sub_ei, mapping = _sample_subgraph_2hop(
            batch_targets, nbrs, max_neighbors=max_neighbors,
        )
        sub_x = x_cpu[subset].to(device, non_blocking=True)
        sub_ei_dev = sub_ei.to(device, non_blocking=True)
        with torch.no_grad():
            logits = ensemble(sub_x, sub_ei_dev)
        batch_logits = logits[mapping]
        probs = torch.softmax(batch_logits, dim=1)[:, 1]
        y_batch = full_y[batch_targets]
        all_scores.append(probs.detach().cpu().numpy())
        all_labels.append(y_batch.numpy())
        del subset, sub_ei, sub_ei_dev, mapping, sub_x, logits, batch_logits
        if device.type == "cuda":
            torch.cuda.empty_cache()

    val_scores = np.concatenate(all_scores) if all_scores else np.array([])
    val_labels_arr = np.concatenate(all_labels) if all_labels else np.array([])
    try:
        ens_auc = roc_auc_score(val_labels_arr, val_scores)
    except ValueError:
        ens_auc = 0.5
    print(f"[B-v6] Ensemble validation AUC: {ens_auc:.4f}")

    os.makedirs(args.model_dir, exist_ok=True)
    save_path = os.path.join(args.model_dir, f"{args.kerberos}_model_B.pt")
    ensemble = ensemble.cpu().eval()
    torch.save(ensemble, save_path)
    print(f"[B-v6] Saved ensemble ({len(members)} members) to {save_path}")
