
import os
import time

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GCN2Conv

from load_dataset import load_dataset


class LinkGCNII(nn.Module):
    def __init__(self, in_dim, hidden_dim=128, out_dim=128,
                 num_layers=8, alpha=0.1, theta=0.5, dropout=0.3):
        super().__init__()
        self.input_proj = nn.Linear(in_dim, hidden_dim)
        self.output_proj = nn.Linear(hidden_dim, out_dim)
        self.convs = nn.ModuleList([
            GCN2Conv(channels=hidden_dim, alpha=alpha, theta=theta,
                     layer=i + 1, shared_weights=True, normalize=True)
            for i in range(num_layers)
        ])
        self.dropout = dropout

        self.decoder = nn.Sequential(
            nn.Linear(2 * out_dim, hidden_dim * 2),
            nn.LayerNorm(hidden_dim * 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, 1),
        )

    def encode(self, x, edge_index):
        x = F.dropout(x, p=self.dropout, training=self.training)
        x = x_0 = F.relu(self.input_proj(x))
        for conv in self.convs:
            x = F.dropout(x, p=self.dropout, training=self.training)
            x = F.relu(conv(x, x_0, edge_index))
        x = self.output_proj(x)
        return x

    def decode(self, z, edge_pairs):
        src = edge_pairs[:, 0]
        dst = edge_pairs[:, 1]
        z_u = z[src]
        z_v = z[dst]
        feat = torch.cat([z_u * z_v, (z_u - z_v).abs()], dim=-1)
        return self.decoder(feat).squeeze(-1)

    def forward(self, x, edge_index, edge_pairs):
        z = self.encode(x, edge_index)
        return self.decode(z, edge_pairs)


class EnsembleC(nn.Module):
    def __init__(self, members):
        super().__init__()
        self.members = nn.ModuleList(members)

    def forward(self, x, edge_index, edge_pairs):
        scores = None
        for m in self.members:
            s = m(x, edge_index, edge_pairs)
            scores = s if scores is None else scores + s
        return scores / len(self.members)


def hits_at_k(pos_scores, neg_scores, k: int = 50) -> float:
    n_neg_higher = (neg_scores > pos_scores.unsqueeze(1)).sum(dim=1)
    return (n_neg_higher < k).float().mean().item()


def _drop_edges(edge_index, drop_prob: float):
    if drop_prob <= 0.0:
        return edge_index
    E = edge_index.shape[1]
    keep = torch.rand(E, device=edge_index.device) > drop_prob
    return edge_index[:, keep]


def _train_one_seed(seed, x, edge_index, train_pos, train_neg_given,
                    valid_pos, valid_neg, N, in_dim, device, time_budget_s):
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    model = LinkGCNII(in_dim=in_dim, hidden_dim=128, out_dim=128,
                       num_layers=8, alpha=0.1, theta=0.5, dropout=0.3).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=3e-3, weight_decay=1e-5)

    max_epochs = 2500
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=max_epochs, eta_min=1e-5,
    )

    best_hits = 0.0
    best_state = None
    start = time.time()

    num_train_pos = train_pos.shape[0]
    edge_drop = 0.3
    neg_ratio = 10
    patience_epochs = 500
    no_improve = 0

    for epoch in range(max_epochs):
        if time.time() - start > time_budget_s:
            break

        model.train()
        optimizer.zero_grad()
        ei_drop = _drop_edges(edge_index, edge_drop)
        z = model.encode(x, ei_drop)

        rand_neg = torch.randint(0, N, (num_train_pos * neg_ratio, 2), device=device)
        neg_pairs = torch.cat([train_neg_given, rand_neg], dim=0)

        pos_scores = model.decode(z, train_pos)
        neg_scores = model.decode(z, neg_pairs)
        logits = torch.cat([pos_scores, neg_scores])
        labels = torch.cat([
            torch.ones_like(pos_scores),
            torch.zeros_like(neg_scores),
        ])
        loss = F.binary_cross_entropy_with_logits(logits, labels)
        loss.backward()
        optimizer.step()
        scheduler.step()

        model.eval()
        with torch.no_grad():
            val_pos_scores = model(x, edge_index, valid_pos)
            V, K, _ = valid_neg.shape
            val_neg_scores = model(x, edge_index, valid_neg.view(V * K, 2)).view(V, K)
            hits = hits_at_k(val_pos_scores, val_neg_scores, k=50)

        if hits > best_hits:
            best_hits = hits
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            no_improve = 0
        else:
            no_improve += 1
            if no_improve >= patience_epochs:
                break

        if epoch % 50 == 0:
            print(f"[C-gcnii][seed={seed}] Epoch {epoch:4d} | Loss {loss.item():.4f} | "
                  f"Hits@50 {hits:.4f} | Best {best_hits:.4f}")

    print(f"[C-gcnii][seed={seed}] Finished. Best Hits@50 = {best_hits:.4f}")

    member = LinkGCNII(in_dim=in_dim, hidden_dim=128, out_dim=128,
                        num_layers=8, alpha=0.1, theta=0.5, dropout=0.3)
    if best_state is not None:
        member.load_state_dict(best_state)
    member.eval()
    return member, best_hits


def train_C_gcnii(args) -> None:
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"[C-gcnii] Device: {device}")

    ds = load_dataset("C", args.data_dir)
    N = int(ds.x.shape[0])
    in_dim = int(ds.x.shape[1])
    print(f"[C-gcnii] Nodes={N}, Features={in_dim}")

    x = ds.x.to(device).float()
    edge_index = ds.edge_index.to(device)
    train_pos = ds.train_pos.to(device)
    train_neg_given = ds.train_neg.to(device)
    valid_pos = ds.valid_pos.to(device)
    valid_neg = ds.valid_neg.to(device)

    seeds = [42, 7, 123, 2024, 0]
    total_budget = 0.85 * 2 * 3600.0
    per_seed = total_budget / len(seeds)

    members = []
    for s in seeds:
        member, _ = _train_one_seed(
            s, x, edge_index, train_pos, train_neg_given,
            valid_pos, valid_neg, N, in_dim, device, per_seed,
        )
        members.append(member)

    ensemble = EnsembleC(members).to(device).eval()
    with torch.no_grad():
        V, K, _ = valid_neg.shape
        ens_pos = ensemble(x, edge_index, valid_pos)
        ens_neg = ensemble(x, edge_index, valid_neg.view(V * K, 2)).view(V, K)
        ens_hits = hits_at_k(ens_pos, ens_neg, k=50)
    print(f"[C-gcnii] Ensemble validation Hits@50: {ens_hits:.4f}")

    os.makedirs(args.model_dir, exist_ok=True)
    save_path = os.path.join(args.model_dir, f"{args.kerberos}_model_C.pt")
    ensemble = ensemble.cpu().eval()
    torch.save(ensemble, save_path)
    print(f"[C-gcnii] Saved ensemble ({len(members)} members) to {save_path}")
