
import argparse
import os
import sys


def main():
    parser = argparse.ArgumentParser(
        description="Train a GNN for COL761 A3 Q2."
    )
    parser.add_argument("--dataset",   required=True, choices=["A", "B", "C"])
    parser.add_argument("--task",      required=True, choices=["node", "link"],
                        help="Task type: node classification (A/B) or link prediction (C)")
    parser.add_argument("--data_dir",  required=True,
                        help="Absolute path to the datasets directory")
    parser.add_argument("--model_dir", required=True,
                        help="Absolute path to the directory where the trained "
                             "model will be saved as {kerberos}_model_{dataset}.pt")
    parser.add_argument("--kerberos",  required=True,
                        help="Your kerberos ID, used to name the saved model")
    args = parser.parse_args()

    valid = {"node": ("A", "B"), "link": ("C",)}
    if args.dataset not in valid[args.task]:
        parser.error(
            f"--task {args.task} is not valid for --dataset {args.dataset}. "
            f"Expected dataset in {valid[args.task]}."
        )

    if not os.path.isabs(args.data_dir):
        parser.error("--data_dir must be an absolute path")

    os.makedirs(args.model_dir, exist_ok=True)

    if args.dataset == "A":
        from model_A_appnp_xl import train_A_appnp_xl as fn
    elif args.dataset == "B":
        from model_B_v6 import train_B_v6 as fn
    elif args.dataset == "C":
        from model_C_gcnii import train_C_gcnii as fn
    else:
        sys.exit(f"Unknown dataset {args.dataset}")

    fn(args)


if __name__ == "__main__":
    main()
